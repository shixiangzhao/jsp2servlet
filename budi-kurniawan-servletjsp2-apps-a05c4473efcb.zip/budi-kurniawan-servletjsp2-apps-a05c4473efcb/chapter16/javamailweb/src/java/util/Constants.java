package util;

public class Constants {
    public static int ROWS_PER_PAGE = 20;
}
