package appdesign3.action;

import appdesign3.model.Product;

public class SaveProductAction {
	public void save(Product product) {
		// insert Product to the database
	}
}
