package test;
import util.PDFUtil;

public class PdfBoxTest {
    public static void main(String[] args) {
        PDFUtil.createDocument("/home/budi2020/Downloads/helloworld.pdf", 
                "Tod late");
    }
}