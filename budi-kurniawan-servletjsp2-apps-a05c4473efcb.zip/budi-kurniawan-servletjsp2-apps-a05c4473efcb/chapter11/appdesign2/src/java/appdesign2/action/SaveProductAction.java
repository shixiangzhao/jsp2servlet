package appdesign2.action;

import appdesign2.model.Product;

public class SaveProductAction {
	public void save(Product product) {
		// insert Product to the database
	}
}
